const UserService = require('../services/user-service');
const User = require('../models/user');

class UserController {
  static async createUser(req, res) {
    const { userID, firstName, lastName, email } = req.body;
    const newUser = new User(userID, firstName, lastName, email);
    
    try {
      const createdUserID = await UserService.createUser(newUser);
      res.status(201).json({ UserID: createdUserID, ...newUser });
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ error: 'Error creating user.' });
    }
  }

  static async getAllUsers(req, res) {
    try {
      const users = await UserService.getAllUsers();
      res.status(200).json(users);
    } catch (error) {
      console.error('Error getting all users:', error);
      res.status(500).json({ error: 'Error getting all users.' });
    }
  }
}

module.exports = UserController;
