// db.js
const sqlite3 = require('sqlite3').verbose();

class Database {
  constructor() {
    this.db = new sqlite3.Database(':memory:');
    this.createTables();
  }

  createTables() {
    this.db.serialize(() => {
      this.db.run("CREATE TABLE IF NOT EXISTS Users (UserID INTEGER PRIMARY KEY, FirstName TEXT, LastName TEXT, Email TEXT)");
      this.db.run("CREATE TABLE IF NOT EXISTS Profiles (ProfileID INTEGER PRIMARY KEY, Description TEXT, Preferences TEXT, UserID INTEGER, FOREIGN KEY(UserID) REFERENCES Users(UserID))");
      this.db.run("CREATE TABLE IF NOT EXISTS Messages (MessageID INTEGER PRIMARY KEY, Content TEXT, DateSent DATETIME, SenderID INTEGER, ReceiverID INTEGER, Status TEXT, FOREIGN KEY(SenderID) REFERENCES Users(UserID), FOREIGN KEY(ReceiverID) REFERENCES Users(UserID))");
    });
  }

  close() {
    this.db.close();
  }
}

module.exports = new Database();
