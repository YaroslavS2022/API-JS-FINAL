// services/user-service.js
const db = require('../db');
const User = require('../models/user');

class UserService {
  static createUser(user) {
    return new Promise((resolve, reject) => {
      const { userID, firstName, lastName, email } = user;
      const sql = "INSERT INTO Users (UserID, FirstName, LastName, Email) VALUES (?, ?, ?, ?)";
      db.db.run(sql, [userID, firstName, lastName, email], function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  static getAllUsers() {
    return new Promise((resolve, reject) => {
      const sql = "SELECT * FROM Users";
      db.db.all(sql, [], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          const users = rows.map(row => new User(row.UserID, row.FirstName, row.LastName, row.Email));
          resolve(users);
        }
      });
    });
  }
}

module.exports = UserService;


/*Structure, architecture generale, microservices, modèle de commmuniication, modèle de stockage*/
/* Fqire des bqdgesm possible des qvqntqge / restrictions */