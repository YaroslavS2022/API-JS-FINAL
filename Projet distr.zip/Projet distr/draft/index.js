// User class
class User {
  constructor(UserID, FirstName, LastName, Email) {
    this.UserID = UserID;
    this.FirstName = FirstName;
    this.LastName = LastName;
    this.Email = Email;
  }
}

// Profile class
class Profile {
  constructor(ProfileID, Description, Preferences, UserID) {
    this.ProfileID = ProfileID;
    this.Description = Description;
    this.Preferences = Preferences;
    this.UserID = UserID;
  }
}

// Message class
class Message {
  constructor(MessageID, Content, DateSent, SenderID, ReceiverID, Status) {
    this.MessageID = MessageID;
    this.Content = Content;
    this.DateSent = DateSent;
    this.SenderID = SenderID;
    this.ReceiverID = ReceiverID;
    this.Status = Status;
  }
}

// Dummy data for testing
const users = [
  new User(1, "John", "Doe", "john@example.com"),
  new User(2, "Jane", "Smith", "jane@example.com")
];

const profiles = [
  new Profile(1, "I love rock music", "Rock, Jazz", 1),
  new Profile(2, "Into pop and hip-hop", "Pop, Hip-hop", 2)
];

const messages = [
  new Message(1, "Hey there!", new Date(), 1, 2, "unread"),
  new Message(2, "Hi, how are you?", new Date(), 2, 1, "unread")
];

// API endpoints
const API = {
  getUsers: () => users,
  getUserByID: (userID) => users.find(user => user.UserID === userID),
  getProfiles: () => profiles,
  getProfileByID: (profileID) => profiles.find(profile => profile.ProfileID === profileID),
  getMessages: () => messages,
  getMessagesByUserID: (userID) => messages.filter(message => message.ReceiverID === userID),
  sendMessage: (message) => {
    messages.push(message);
    return message;
  }
};

// Test API
console.log(API.getUsers());
console.log(API.getUserByID(1));
console.log(API.getProfiles());
console.log(API.getProfileByID(1));
console.log(API.getMessages());
console.log(API.getMessagesByUserID(2));
console.log(API.sendMessage(new Message(3, "Test message", new Date(), 1, 2, "unread")));
