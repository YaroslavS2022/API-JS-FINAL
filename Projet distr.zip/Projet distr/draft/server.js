// server.js
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

let messages = [];

// Endpoint to send a message
app.post('/send-message', (req, res) => {
  const { senderID, receiverID, content } = req.body;
  const message = {
    id: messages.length + 1,
    senderID,
    receiverID,
    content,
    timestamp: new Date()
  };
  messages.push(message);
  console.log(`Message sent from User ${senderID} to User ${receiverID}: ${content}`);
  res.status(200).json({ message: 'Message sent successfully.' });
});

// Endpoint to retrieve messages for a user
app.get('/messages/:userID', (req, res) => {
  const userID = parseInt(req.params.userID);
  const userMessages = messages.filter(message => message.receiverID === userID || message.senderID === userID);
  res.status(200).json(userMessages);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
