// models/user.js
class User {
  constructor(userID, firstName, lastName, email) {
    this.userID = userID;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
  }
}

module.exports = User;
