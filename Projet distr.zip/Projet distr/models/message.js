// models/message.js
class Message {
  constructor(content, senderID, receiverID, status) {
    this.content = content;
    this.senderID = senderID;
    this.receiverID = receiverID;
    this.status = status;
    this.dateSent = new Date().toISOString();
  }
}

module.exports = Message;
