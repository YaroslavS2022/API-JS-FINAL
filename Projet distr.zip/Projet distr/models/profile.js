// models/profile.js
class Profile {
  constructor(description, preferences, userID) {
    this.description = description;
    this.preferences = preferences;
    this.userID = userID;
  }
}

module.exports = Profile;
